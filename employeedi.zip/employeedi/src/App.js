import React from 'react';
import TableArea from './components/TableArea';


function App() {
  return (
    <div>
      <TableArea>

      </TableArea>
      </div>
      
  );
}

export default App;
